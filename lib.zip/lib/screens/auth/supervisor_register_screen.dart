import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login_screen.dart';

class SupervisorRegisterScreen extends StatefulWidget {
  const SupervisorRegisterScreen({super.key});

  @override
  State<SupervisorRegisterScreen> createState() => _SupervisorRegisterScreenState();
}

class _SupervisorRegisterScreenState extends State<SupervisorRegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  String name = '';
  String email = '';
  String password = '';
  String confirmPassword = '';
  bool isLoading = false;

  Future<void> registerSupervisor() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => isLoading = true);

    try {
      final auth = FirebaseAuth.instance;
      final firestore = FirebaseFirestore.instance;

      UserCredential userCred = await auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      User? user = userCred.user;

      // 🔹 Send verification email (commented for now)
      // await user?.sendEmailVerification();

      String uid = user!.uid;

      await firestore.collection('users').doc(uid).set({
        'name': name,
        'email': email,
        'role': 'supervisor',
        'createdAt': Timestamp.now(),
        // 'emailVerified': false,
      });

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'Registration successful! (Enable email verification to require verified accounts.)')),
        );
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 26),
              decoration: BoxDecoration(
                color: colorScheme.secondary,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              child: Column(
                children: [
                  const Icon(Icons.engineering, color: Colors.white, size: 32),
                  const SizedBox(height: 4),
                  const Text(
                    'Register as Site Supervisor',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 22,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Help manage worksite progress',
                    style: TextStyle(
                      color: Colors.white.withOpacity(.8),
                      fontSize: 13.5,
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 450),
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 30),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _styledField(
                                label: 'Full Name',
                                icon: Icons.person_outline,
                                onChanged: (val) => name = val.trim(),
                                validator: (val) =>
                                    val == null || val.isEmpty ? 'Required' : null,
                              ),
                              const SizedBox(height: 14),
                              _styledField(
                                label: 'Email',
                                icon: Icons.email_outlined,
                                keyboardType: TextInputType.emailAddress,
                                onChanged: (val) => email = val.trim(),
                                validator: (val) => val != null && val.contains('@')
                                    ? null
                                    : 'Enter valid email',
                              ),
                              const SizedBox(height: 14),
                              _styledField(
                                label: 'Password',
                                icon: Icons.lock_outline,
                                obscureText: true,
                                onChanged: (val) => password = val,
                                validator: (val) =>
                                    val != null && val.length >= 6
                                        ? null
                                        : 'Min 6 characters',
                              ),
                              const SizedBox(height: 14),
                              _styledField(
                                label: 'Confirm Password',
                                icon: Icons.lock_reset,
                                obscureText: true,
                                onChanged: (val) => confirmPassword = val,
                                validator: (val) =>
                                    val != password ? 'Passwords do not match' : null,
                              ),
                              const SizedBox(height: 28),
                              SizedBox(
                                height: 50,
                                child: FilledButton(
                                  style: FilledButton.styleFrom(
                                    backgroundColor: colorScheme.secondary,
                                    foregroundColor: colorScheme.onSecondary,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15)),
                                  ),
                                  onPressed: isLoading ? null : registerSupervisor,
                                  child: isLoading
                                      ? const CircularProgressIndicator(
                                          strokeWidth: 2, color: Colors.white)
                                      : const Text('Register'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _styledField({
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    bool obscureText = false,
    required ValueChanged<String> onChanged,
    String? Function(String?)? validator,
  }) =>
      TextFormField(
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
        obscureText: obscureText,
        keyboardType: keyboardType,
        onChanged: onChanged,
        validator: validator,
      );
}
